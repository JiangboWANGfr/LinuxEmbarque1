#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

#include <fcntl.h>
#include <unistd.h>

/* Corrigé du TD 1 de linux embarqué
 * Il y a 4 fichiers, il faut les exécuter dans l'ordre :
 * 1. asserv_write.c
 * 2. asserv_read.c
 * 3. asserv_printf.c
 * 4. asserv_scanf.c (celui-là)
 *
 * Pour compiler :
 * gcc asserv_scanf.c -o asserv_scanf
 *
 * Pour exécuter :
 * ./asserv_scanf
 */

typedef struct asserv {
	char version[10];		// 12
	float taille_roue;		// 4
	double entraxe;			// 8
	uint8_t ratio;			// 4
	uint16_t p;				// 4
	uint32_t i;				// 4
	int32_t d;				// 4
} asserv_t;					// 40

int main (int argc, char ** argv)
{
	asserv_t asserv;

	printf("Taille asserv_t = %d\n", sizeof(asserv_t));

	FILE * fid = fopen("asserv.txt", "r+");
	if (fid == NULL)
	{
		printf("Error opening file\n");
		exit(-1);
	}

	fscanf(fid, "%s\n", asserv.version);
	fscanf(fid, "%f\n", &asserv.taille_roue);
	fscanf(fid, "%lf\n", &asserv.entraxe);
	fscanf(fid, "%u\n", &asserv.ratio);
	fscanf(fid, "%u\n", &asserv.p);
	fscanf(fid, "%u\n", &asserv.i);
	fscanf(fid, "%d\n", &asserv.d);

	printf("Version = %s\n", asserv.version);
	printf("Taille roue = %f\n", asserv.taille_roue);
	printf("Entraxe = %lf\n", asserv.entraxe);
	printf("Ratio = %u\n", asserv.ratio);
	printf("P = %u\n", asserv.p);
	printf("I = %u\n", asserv.i);
	printf("D = %d\n", asserv.d);

	return 0;
}
