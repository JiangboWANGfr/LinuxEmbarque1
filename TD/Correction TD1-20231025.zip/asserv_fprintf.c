#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

#include <fcntl.h>
#include <unistd.h>

/* Corrigé du TD 1 de linux embarqué
 * Il y a 4 fichiers, il faut les exécuter dans l'ordre :
 * 1. asserv_write.c
 * 2. asserv_read.c
 * 3. asserv_printf.c (celui-là)
 * 4. asserv_scanf.c
 *
 * Pour compiler :
 * gcc asserv_printf.c -o asserv_printf
 *
 * Pour exécuter :
 * ./asserv_printf
 */

typedef struct asserv {
	char version[10];		// 12
	float taille_roue;		// 4
	double entraxe;			// 8
	uint8_t ratio;			// 4
	uint16_t p;				// 4
	uint32_t i;				// 4
	int32_t d;				// 4
} asserv_t;					// 40

int main (int argc, char ** argv)
{
	asserv_t asserv;

	printf("Taille asserv_t = %d\n", sizeof(asserv_t));

	printf("Version : \n");
	scanf ("%s", asserv.version);
	printf("Taille roue : \n");
	scanf ("%f", &asserv.taille_roue);
	printf("Entraxe: \n");
	scanf ("%lf", &asserv.entraxe);
	printf("Ratio : \n");
	scanf ("%u", &asserv.ratio);
	printf("p : \n");
	scanf ("%u", &asserv.p);
	printf("i : \n");
	scanf ("%u", &asserv.i);
	printf("d : \n");
	scanf ("%d", &asserv.d);

	FILE * fid = fopen("asserv.txt", "w+");
	if (fid == NULL)
	{
		printf("Error opening file\n");
		exit(-1);
	}

	fprintf(fid, "%s\n", asserv.version);
	fprintf(fid, "%f\n", asserv.taille_roue);
	fprintf(fid, "%lf\n", asserv.entraxe);
	fprintf(fid, "%u\n", asserv.ratio);
	fprintf(fid, "%u\n", asserv.p);
	fprintf(fid, "%u\n", asserv.i);
	fprintf(fid, "%d\n", asserv.d);

	return 0;
}
